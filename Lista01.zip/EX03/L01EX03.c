/* ================================================================== *
	Universidade Federal de Sao Carlos - UFSCar, Sorocaba

	Lista 01 - Exercício 03 - Validacao de e-mails

	Instrucoes
	----------

	Este arquivo contem o codigo que auxiliara no desenvolvimento do
	exercicio. Voce precisara completar as partes requisitadas.

* ================================================================== *
	Dados do aluno:

	RA: 
	Nome: 

* ================================================================== */

#include <stdio.h>
#include <string.h>

int email_valido(char email[]);

int main() {
    int tamanho;
    char email[51];
    
    while (scanf("%d", &tamanho) && tamanho > 0) {
        scanf(" %50[^\n]", email);
        
        if (email_valido(email))
            printf("Valido\n");
        else
            printf("Invalido\n");
    }
    
    return (0);
}

int email_valido(char email[]) {
    
    /* IMPLEMENTE SEU CODIGO AQUI */
    
    /* Esta funcao deve retornar 1 caso o e-mail seja valido e 0 caso contrario */
    /* É permitido criar outras funcoes para auxiliar na validacao do e-mail */
    
}
