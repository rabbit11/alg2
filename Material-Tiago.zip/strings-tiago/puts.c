#include <stdio.h>

int main (void) 
{  
	char str[] = "Prova de Alg1 é pancadona.";

	printf("%s\n", str);
	puts (str);

	return 0;
}
