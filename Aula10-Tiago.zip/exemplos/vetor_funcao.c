/*
 * L� um vetor de um arquivo texto. O primeiro inteiro lido �
 * a dimens�o do vetor.
 *
 * Escreve o vetor em um arquivo de sa��da bin�rio. 
 *
 * L� um vetor do arquivo bin�rio e o escreve em um arquivo texto.
 */

#include <stdio.h>
#include <stdlib.h>

int *le_vetor_texto(int *n, char *fileName) {
  FILE  *fr;
  int *v;
  int i;

  fr = fopen (fileName, "r");
  if (fr == NULL) {
    perror(fileName);
    exit(-1);
  }
  
  fscanf(fr, "%d", n); // le a dimensao do vetor
  v = (int *) malloc (*n * sizeof(int)); // aloca o vetor
  
  for (i = 0; i < *n; i++) // le cada elemento do vetor
    fscanf(fr, "%d", &v[i]);

  fclose(fr);
  
  return v;
}

int *le_vetor_binario(int *n, char *fileName) {
  FILE  *fr;
  int *v;

  fr = fopen (fileName, "rb");
  if (fr == NULL) {
    perror(fileName);
    exit(-1); 
  }
  
  fread(n, sizeof(int), 1, fr); // le o tamanho do vetor
  v = (int *) malloc (*n * sizeof(int)); // aloca o vetor
  
  fread(v, sizeof(int), *n, fr); // le o vetor inteiro

  fclose(fr);
  
  return v;
}

void escreve_vetor_texto(int *v, int n, char *fileName) {
  FILE  *fw;
  int i;

  fw = fopen (fileName, "w");
  if (fw == NULL) {
    perror(fileName);
    exit(-1);
  }
  
  fprintf(fw, "%d\n", n); // escreve a dimens�o do vetor
  
  for (i = 0; i < n; i++)
    fprintf(fw, "%d\n", v[i]); // escreve elemento a elemento

  fclose(fw);  
}

void escreve_vetor_binario(int *v, int n, char *fileName) {
  FILE  *fw;

  fw = fopen (fileName, "wb");
  if (fw == NULL) {
    perror(fileName);
    exit(-1);
  }
  
  fwrite(&n, sizeof(int), 1, fw); // escreve a dimens�o do vetor
  fwrite(v, sizeof(int), n, fw);  // escreve o vetor inteiro

  fclose(fw);  
}

int main() {
  char textFileIn[255] = "v-in.txt", textFileOut[255] = "v-out.txt", binFile[255] = "v.bin"; 
  int *v1, *v2;
  int n1, n2;
  
  v1 = le_vetor_texto(&n1, textFileIn);
  escreve_vetor_binario(v1, n1, binFile);
  
  v2 = le_vetor_binario(&n2, binFile);
  escreve_vetor_texto(v2, n2, textFileOut);

  free(v1);
  free(v2);
  
  return 0;

}
